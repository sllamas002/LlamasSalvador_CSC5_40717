/* 
 * File:   main.cpp
 * Author: Salvador Llamas
 *
 * Created on January 8, 2015, 11:47 AM
 * Purpose:14. Personal Information
Write a program that displays the following pieces of information, each on a separate line:
Your name
Your address, with city, state, and ZIP code
Your telephone number
Your college major

 */
//System Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

/*User Libraries
 * Global Constants
 * Prototype Function
 * Execution Begin Here!
 */
int main(int argc, char** argv) {
     //Displays the pieces of information.
    cout<<" Your name\n Your address,with city,State, and Zip Code \n Your telephone";
    cout<<" number \n Your college major"<<endl;
    
    //Exit
    return 0;
}

